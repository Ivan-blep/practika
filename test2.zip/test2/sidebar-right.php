<?php
/**
 * Sidebar
 *
 * Content for our sidebar, provides prompt for logged in users to create widgets
 */
?>

<?php dynamic_sidebar( 'Sidebar Right' ); ?>