<?php

use Elementor\Controls_Manager;
use Elementor\Utils;

class Custom_Widget extends \Elementor\Widget_Base {
	/**
	 * Get widget name.
	 *
	 * Retrieve widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'custom_widget';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Custom Widget', 'default' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-cog';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @return array Widget categories.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Register widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @see https://code.elementor.com/classes/elementor-controls_manager/
	 * @see https://developers.elementor.com/elementor-controls/
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section( 'section_nav', [
			'label' => __( 'Settings', 'default' ),
			'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
		] );

		$this->add_control( 'message', [
			'type'            => \Elementor\Controls_Manager::RAW_HTML,
			'raw'             => __( 'Use this field to display some message if widget does not has any settings.' ),
			'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
		] );

		$this->add_control( 'setting_name', [
			'label'   => __( 'Setting Name', 'default' ),
			'type'    => \Elementor\Controls_Manager::TEXT,
			'default' => '',
		] );

		$this->add_control( 'setting_name_2', [
			'label'   => __( 'Select Post', 'default' ),
			'type'    => \Elementor\Controls_Manager::SELECT2,
			'options' => $this->get_posts_list( 'post' ),
			'default' => array_keys( $this->get_posts_list( 'post' ) )[0],
		] );

		$this->end_controls_section();
	}

	protected function get_terms( $taxonomy ) {
		$ind_args = [
			'taxonomy'   => $taxonomy,
			'hide_empty' => true,
		];
		$terms    = get_terms( $ind_args );
		$options  = [];
		if ( $terms ) {
			foreach ( $terms as $industry ) {
				$options[ $industry->term_id ] = $industry->name;
			}
		}

		return $options;
	}

	protected function get_posts_list( $post_type ) {
		$options    = [];
		$items_args = array(
			'post_type'              => $post_type,
			'posts_per_page'         => 100,
			'orderby'                => 'title',
			'order'                  => 'ASC',
			'no_found_rows'          => true, // counts posts, remove if pagination required
			'update_post_term_cache' => false, // grabs terms, remove if terms required (category, tag...)
			'update_post_meta_cache' => false, // grabs post meta, remove if post meta required
		);
		$items      = get_posts( $items_args );

		if ( $items ) {
			foreach ( $items as $item ) {
				$options[ $item->ID ] = $item->post_title;
			}
		}

		return $options;
	}

	/**
	 * Render widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		
		$widget_wrapper_css_class = 'custom-widget';
		$this->add_render_attribute( 'wrapper', 'class', $widget_wrapper_css_class );
		$setting_name = $settings['setting_name'];
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php var_dump( $setting_name ); // Widget markup ?>
		</div>
		<?php
	}
}