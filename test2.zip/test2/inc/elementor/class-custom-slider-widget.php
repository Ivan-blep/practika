<?php

use Elementor\Controls_Manager;
use Elementor\Utils;

class Slider_Widget extends \Elementor\Widget_Base {
	/**
	 * Get widget name.
	 *
	 * Retrieve widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'slider_widget';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Custom Slider Widget', 'default' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-cog';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @return array Widget categories.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Register widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @see https://code.elementor.com/classes/elementor-controls_manager/
	 * @see https://developers.elementor.com/elementor-controls/
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

        $this->start_controls_section(
            'section_style',
            [
                'label' => __( 'Style', 'ti' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'label' => __( 'Content Typography', 'ti' ),
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selector' => '{{WRAPPER}} .slid .post-content',
            ]
        );
        $this->add_responsive_control(
            'content_color',
            [
                'label' => __( 'Content Color', 'ti' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selectors' => [
                    '{{WRAPPER}} .slid .post-content' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'content_margin_bottom',
            [
                'label' => __( 'Content margin bottom', 'ti' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'size_units' => ['px', 'em', 'vh', 'vw'],
                'default'   => ['unit' => 'px', 'size' => 0],
                'selectors' => [
                    '{{WRAPPER}} .slid .post-content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __( 'Title Typography', 'ti' ),
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selector' => '{{WRAPPER}} .slid .author',
            ]
        );
        $this->add_responsive_control(
            'title_color',
            [
                'label' => __( 'Title Color', 'ti' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selectors' => [
                    '{{WRAPPER}} .slid .author' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'job_title_typography',
                'label' => __( 'Job title Typography', 'ti' ),
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selector' => '{{WRAPPER}} .slid .job-title',
            ]
        );
        $this->add_responsive_control(
            'job_title_color',
            [
                'label' => __( 'Job title Color', 'ti' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selectors' => [
                    '{{WRAPPER}} .slid .job-title' => 'color: {{VALUE}};',
                ],
            ]
        );


        $this->add_responsive_control(
            'background_color',
            [
                'label' => __( 'Background Color', 'ti' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selectors' => [
                    '{{WRAPPER}} .slid' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'padding',
            [
                'label' => __( 'Padding', 'ti' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', 'vh', 'vw'],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selectors' => [
                    '{{WRAPPER}} .slid .slid-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'border_radius',
            [
                'label' => __( 'Border radius', 'ti' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'vh', 'vw'],
                'default'   => ['unit' => 'px', 'size' => 0],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selectors' => [
                    '{{WRAPPER}} .slid' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'spaces_between',
            [
                'label' => __( 'Spaces between slides', 'ti' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'vh', 'vw'],
                'default'   => ['unit' => 'px', 'size' => 0],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selectors' => [
                    '{{WRAPPER}} .slick-slide' => 'padding: 0 {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .slick-list' => 'margin: 0 -{{SIZE}}{{UNIT}};'
                ],
            ]
        );
        $this->add_responsive_control(
            'size_image',
            [
                'label' => __( 'Size image', 'ti' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'vh', 'vw'],
                'default'   => ['unit' => 'px', 'size' => 58],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selectors' => [
                    '{{WRAPPER}} .slid img' => 'width: {{SIZE}}{{UNIT}}; height: 0 -{{SIZE}}{{UNIT}};',
            ]
            ]
        );
        $this->add_responsive_control(
            'margin_right_image',
            [
                'label' => __( 'Margin right image', 'ti' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'vh', 'vw'],
                'default'   => ['unit' => 'px', 'size' => 0],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selectors' => [
                    '{{WRAPPER}} .slid img' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'slides_to_show',
            [
                'label' => __( 'Slides to Show', 'ti' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'default' => 3,
                'min' => 1,
                'max' => 5,
            ]
        );

        $this->add_responsive_control(
            'slides_to_scroll',
            [
                'label' => __( 'Slides to Scroll', 'ti' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'default' => 1,
                'min' => 1,
                'max' => 5,
            ]
        );

        $this->add_responsive_control(
            'selected_icon',
            [
                'label' => __( 'Select Arrow Icon', 'ti' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'fa-solid',
                ],
            ]
        );
        $this->add_responsive_control(
            'size_arrow',
            [
                'label' => __( 'Size Arrow', 'ti' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'vh', 'vw'],
                'default'   => ['unit' => 'px', 'size' => 20],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'selectors' => [
                    '{{WRAPPER}} .slick-arrow' => 'font-size: {{SIZE}}{{UNIT}}  !important;',
                ]
            ]
        );



        $this->end_controls_section();
    }

protected function get_testimonials(){
        $options = [];
        $testimonials_args = array(
            'post_type'  => '_reviews',
            'post_per_page'         => 100,
            'orderby'    => 'title',
            'order'      => 'ASC',
        );
        $testimonials = get_posts($testimonials_args);
        if($testimonials){
            foreach ($testimonials as $item){
                $options[$item->ID] = $item->post_title;
            }
        }
        return $options;
}

	/**
	 * Render widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
    protected function render() {

        $widget_wrapper_css_class = 'custom-slider-widget';
        $this->add_render_attribute( 'wrapper', 'class', $widget_wrapper_css_class );

        $reviews_args = array(
            'post_type'      => '_reviews',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
        );

        $reviews = get_posts( $reviews_args );
        $selected_icon = $this->get_settings( 'selected_icon' );
        ?>
        <style>
            .d-flex {
                display: flex;
            }

            .column {
                flex-direction: column;
            }

            .slid .author {
                margin: 5px;
            }

            body .slick-prev,
            body .slick-next {
                top: -45px;
            }
            body .slick-arrow{
                background: white;
                border-radius: 50%;
                color: #0A2640;
                font-size: 16px;
                display: flex;
                align-items: center;
                width: 72px;
                height: 72px;
                justify-content: center;
            }
            body .slick-arrow:active, body .slick-arrow:hover{
                background: #dcdcdc;
                color: #0A2640;
            }
            .slick-prev {
                left: 83%;
                position: relative;
                transform: rotate(180deg) !important;
                top: -80px!important;
            }
            body .slick-arrow:before {
                content: '';
            }
            .align-center{
                align-items: center;
                justify-content: flex-start
            }
            @media (max-width: 1024px) {
                .slick-prev {
                    left: 70%;
                }
                body .slick-next {
                    right: 5px;
                }
            }
            @media (max-width: 767px) {
                body .slick-arrow{
                    width: 40px;
                    height: 40px;
                }
                .slick-prev {
                    left: 65%;
                    top: -65px!important;
                }
                body .slick-next {
                    right: 5px;
                }
            }
        </style>
        <div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
            <?php
            if ( $reviews ) {
                foreach ( $reviews as $review ) {
                    $thumbnail = get_the_post_thumbnail( $review->ID, 'thumbnail' );
                    $content = $review->post_content;
                    $job_title = get_field( 'job_title', $review->ID );
                    echo '<div class="slid">';
                    echo '<div class="slid-container">';
                    echo '<p class="post-content">“' . esc_html( $content ) . '”</p>';
                    echo '<div class="d-flex align-center">';
                    if ( $thumbnail ) {
                        echo '<div class="thumbnail-wrapper">' . $thumbnail . '</div>';
                    }
                    echo '<div class="d-flex column">';
                    echo '<p class="author">' . esc_html( $review->post_title ) . '</p>';
                    if ( $job_title ) {
                        echo '<p class="job-title">' . esc_html( $job_title ) . '</p> ';
                    }
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            }
            ?>
        </div>
        <script type="text/javascript">
            jQuery(document).ready(function ($) {
                $('.custom-slider-widget').slick({
                    slidesToShow: <?php echo esc_html( $this->get_settings( 'slides_to_show' ) ); ?>,
                    slidesToScroll: <?php echo esc_html( $this->get_settings( 'slides_to_scroll' ) ); ?>,
                    responsive: [
                        {
                            breakpoint: 1024,
                            settings: {
                                slidesToShow:2,
                            }
                        },
                        {
                            breakpoint: 768,
                            settings: {
                                slidesToShow:1,
                            }
                        }
                    ]
                });
            });
            document.addEventListener("DOMContentLoaded", function() {
                document.addEventListener('DOMNodeInserted', function(event) {
                    if (event.target.classList && event.target.classList.contains('slick-arrow')) {
                        var selectedIcon = "<?php echo esc_attr($selected_icon['value']); ?>";
                        var prevArrow = event.target;
                        var iconElement = document.createElement("i");
                        iconElement.setAttribute("class", selectedIcon);
                        prevArrow.innerHTML = '';
                        prevArrow.appendChild(iconElement);
                    }
                });
            });
        </script>

        <?php
    }
}