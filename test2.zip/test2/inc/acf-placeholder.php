<?php
if ( ! function_exists( 'the_field' ) ) {
	function the_field() {
		return '';
	}
}

if ( ! function_exists( 'get_field' ) ) {
	function get_field() {
		return '';
	}
}

if ( ! function_exists( 'have_rows' ) ) {
	function have_rows() {
		return '';
	}
}

if ( ! function_exists( 'the_sub_field' ) ) {
	function the_sub_field() {
		return '';
	}
}

if ( ! function_exists( 'get_sub_field' ) ) {
	function get_sub_field() {
		/** @var mixed $param */
		$param = '';
		return $param;
	}
}


//$var = get_sub_field('asd');
//echo $var->title;